let questions = [
    {
        numb: 1,
        question: "World War II started when Germany invaded which country?",
        answer: "D. Poland",
        options: [
            "A. Great Britain",
            "B. France",
            "C. Belgium",
            "D. Poland"
        ]
    },
    {
        numb: 2,
        question: "Which of these best describes blitzkrieg, which was key to Germany’s early success in the war?",
        answer: "A. Quick coordinated attacks",
        options: [
            "A. Quick coordinated attacks",
            "B. High-level Esponiage",
            "C. Propoganda",
            "D. Economic Sanctions"
        ]
    },
    {
        numb: 3,
        question: "Early in the war, in his first address to the British House of Commons, Prime Minister Winston Churchill said, “I have nothing to offer but…” ",
        answer: "A. “An appeal to human decency”",
        options: [
            "A. “An appeal to human decency”",
            "B. “Blood, toil, tears and sweat.”",
            "C. “A swift end to tyranny”",
            "D. “Peace in our time”"
        ]
    },
    {
        numb: 4,
        question: "After World War I, France built the Maginot Line, a string of border fortifications considered impenetrable. How did the German army overcome the Maginot Line in World War II?",
        answer: "C. Went around it",
        options: [
            "A. Bombed it",
            "B. Overwhelmed it with troops",
            "C. Went around it",
            "D. Bribed its way past it"
        ]
    },
    {
        numb: 5,
        question: "Which technology helped the U.K. defeat Germany’s months long air offensive against it in the Battle of Britain?",
        answer: "C. Radar",
        options: [
            "A. Atomic energy",
            "B. Stealth airplanes",
            "C. Radar",
            "D. Rockets"
        ]
    },
    {
        numb: 6,
        question: "Which fortuitous circumstance helped reduce U.S. losses at Pearl Harbor?",
        answer: "A. No American aircraft carriers were in port.",
        options: [
            "A. No American aircraft carriers were in port.",
            "B. Strong winds blew Japanese planes off course.",
            "C. Heavy fog made targeting ships difficult.",
            "D. Base personnel awoke earlier than usual."
        ]
    }
];