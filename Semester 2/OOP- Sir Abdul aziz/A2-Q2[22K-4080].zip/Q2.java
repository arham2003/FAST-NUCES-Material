import java.util.*;

class Course {
    private String name;
    private String code;
    private int cred_hour;
    private float gpa;
    private String grade;

    public void setGpa(float g) {
        gpa = g;
    }

    public String getName() {
        return name;
    }

    public float getGpa() {
        return gpa;
    }

    public String getCode() {
        return code;
    }

    public int getHour() {
        return cred_hour;
    }

    public String getGrade() {
        return grade;
    }

    public void setGrade(String g) {
        grade = g;
    }

    public void setName(String n) {
        name = n;
    }

    public void setCode(String c) {
        code = c;
    }

    public void setHour(int cr) {
        cred_hour = cr;
    }

    public void displayInfo() {
        System.out.println("Course Name:" + name);
        System.out.println("Course Code:" + code);
        System.out.println("Credit Hours:" + cred_hour);
    }

    public void showCredHour() {
        System.out.println("Credit Hours:" + cred_hour);
    }

    public void showCode() {
        System.out.println("Course Code:" + code);
    }
}

class Student {
    private String ID;
    private String name;
    private int num_of_course;
    protected Course[] courses = new Course[7];
    private boolean verify_fees;
    private float GPA;
    private float due_amount;
    private float semester_fees;

    public void set_ID(String id) {
        ID = id;
    }

    public void set_num_of_course(int n) {
        num_of_course = n;
    }

    public void set_name(String n) {
        name = n;
    }

    public float get_semester_fees() {
        return semester_fees;
    }

    public void set_course_info(Course a, int j) {
        courses[j].setName(a.getName());
        courses[j].setCode(a.getCode());
        courses[j].setHour(a.getHour());
        courses[j].setGrade(a.getGrade());
    }

    public int calc_cred_hour() {
        int temp = 0;
        for (int i = 0; i < num_of_course; i++) {
            temp = temp + courses[i].getHour();
        }
        return temp;
    }

    public void calc_gpa(int[] mark) {
        for (int i = 0; i < num_of_course; i++) {
            if (mark[i] < 50) {
                courses[i].setGpa(0.00f);
            } else if (mark[i] >= 50 && mark[i] < 62) {
                courses[i].setGpa(1.00f);
            } else if (mark[i] >= 62 && mark[i] < 66) {
                courses[i].setGpa(2.00f);
            } else if (mark[i] >= 66 && mark[i] < 70) {
                courses[i].setGpa(2.33f);
            } else if (mark[i] >= 70 && mark[i] < 74) {
                courses[i].setGpa(2.67f);
            } else if (mark[i] >= 74 && mark[i] < 78) {
                courses[i].setGpa(3.00f);
            } else if (mark[i] >= 78 && mark[i] < 82) {
                courses[i].setGpa(3.33f);
            } else if (mark[i] >= 82 && mark[i] < 86) {
                courses[i].setGpa(3.67f);
            } else if (mark[i] >= 86 && mark[i] < 100) {
                courses[i].setGpa(4.00f);
            }
        }
    }

    public void calc_GPA() {
        for (int i = 0; i < num_of_course; i++) {
            if (courses[i].getGrade().equals("F")) {
                courses[i].setGpa(0.00f);
            } else if (courses[i].getGrade().equals("D")) {
                courses[i].setGpa(1.00f);
            } else if (courses[i].getGrade().equals("C")) {
                courses[i].setGpa(2.00f);
            } else if (courses[i].getGrade().equals("C+")) {
                courses[i].setGpa(2.33f);
            } else if (courses[i].getGrade().equals("B-")) {
                courses[i].setGpa(2.67f);
            } else if (courses[i].getGrade().equals("B")) {
                courses[i].setGpa(3.00f);
            } else if (courses[i].getGrade().equals("B+")) {
                courses[i].setGpa(3.33f);
            } else if (courses[i].getGrade().equals("A-")) {
                courses[i].setGpa(3.67f);
            } else if (courses[i].getGrade().equals("A")) {
                courses[i].setGpa(4.00f);
            }
        }
        float q_point = 0;
        int t_hour = calc_cred_hour();
        for (int i = 0; i < num_of_course; i++) {
            q_point = q_point + (courses[i].getGpa() * courses[i].getHour());
        }
        GPA = q_point / t_hour;
    }

    public void fees_verification(float amount) {
        if (semester_fees == amount) {
            verify_fees = true;
            due_amount = 0;
        } else if (semester_fees > amount) {
            verify_fees = false;
            due_amount = semester_fees - amount;
        }
    }

    public float get_due_amount() {
        return due_amount;
    }

    public boolean get_verify() {
        return verify_fees;
    }

    public void display_std_info() {
        System.out.println("Student ID: " + ID);
        System.out.println("Student name: " + name);
        System.out.println("Number of Courses: " + num_of_course);
        for (int i = 0; i < num_of_course; i++) {
            courses[i].displayInfo();
            if (verify_fees) {
                System.out.println("Course Grade: " + courses[i].getGrade());
            } else {
                System.out.println("Grade Locked!");
            }
        }
        System.out.println("Total credit hours: " + calc_cred_hour());
        if (verify_fees) {
            System.out.println("Semester GPA: " + GPA);
            System.out.println("Student has paid fees");
        } else {
            System.out.println("Fees has not been paid. Grades are locked");
        }
    }

    public float calcSemesterFees(String id) {
        int tHour;
        float idDigits;
        tHour = calc_cred_hour();
        idDigits = ((id.charAt(1) - 48) * 10) + (id.charAt(2) - 48);
        semester_fees = ((idDigits * 1000) / 2) * tHour;
        return semester_fees;
    }
}
public class Q2 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String id;
        System.out.println("Arham Khan");
        System.out.println("22k-4080\n");
        System.out.print("Enter your ID(Eg:K221234): ");
        id = sc.next();
        int n;
        boolean feePaid;
        n = (id.charAt(5) - 48);
        Student[] std = new Student[5];
        Course c = new Course();
        int num, j, hour;
        float amount;
        String name, c_name, code, grade;
        for (int i = 0; i < n; i++) {
            System.out.print("\nEnter Name of Student " + (i + 1) + ": ");
            name = sc.next();
            std[i] = new Student();
            std[i].set_name(name);
            System.out.print("Enter ID of Student: ");
            String id2 = sc.next();
            std[i].set_ID(id2);
            do {
                System.out.print("Enter Number of Courses of Student(Max=7): ");
                num = sc.nextInt();
                if (num > 7) {
                    System.out.println("Invalid! Enter again\n");
                }
            } while (num > 7);
            std[i].set_num_of_course(num);
            sc.nextLine(); // to clear the scanner buffer
            for (j = 0; j < num; j++) {
                System.out.print("\nEnter name of course " + (j + 1) + ": ");
                c_name = sc.nextLine();
                c.setName(c_name);
                System.out.print("Enter code of course: ");
                code = sc.nextLine();
                c.setCode(code);
                System.out.print("Enter credit hours of course: ");
                hour = sc.nextInt();
                c.setHour(hour);
                System.out.print("Enter grade of course: ");
                grade = sc.nextLine();
                c.setGrade(grade);
                std[i].set_course_info(c, j);
                sc.nextLine(); // to clear the scanner buffer
            }
            System.out.println("\nSemester Fees of student: " + std[i].calcSemesterFees(id));
            do {
                System.out.print("Enter amount to pay: ");
                amount = sc.nextFloat();
                if (amount > std[i].get_semester_fees()) {
                    System.out.println("Invalid! Amount can not be higher than fees. Enter again\n");
                }
            } while (amount > std[i].get_semester_fees());
            std[i].fees_verification(amount);
            std[i].calc_GPA();
        }
        for (int i = 0; i < n; i++) {
            System.out.println("\nStudent " + (i + 1) + " Info:");
            std[i].display_std_info();
            feePaid = std[i].get_verify();
            if (!feePaid) {
                System.out.println("Due Amount: " + std[i].get_due_amount());
            }
            System.out.println();
        }
    }
}

