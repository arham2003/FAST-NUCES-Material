#include <iostream>

using namespace std;

int main(){
	int i,j,k,temp;
	int size;
	cout<<"Enter size of array: "<<endl;
	cin>>size;
	int A[size];
	
	for (i=1;i<=size;i++){
		cout<<"Enter Element "<<i<<":";
		cin>>A[i];
	}
	
	for (j=1;j<n;j++){
		for (i=1;i<n-1;i++){
			if(A[i]>A[i+1]){
				temp=A[i];
				A[i]=A[i+1];
				A[i+1]=temp;
			}
		}
	}
	
	cout<<"Bubble sort is: "<<"\n";
	for(i=0;i<n;i++){
		cout<<A[i]<<"\t";
	}
}
