import java.util.ArrayList;

class Game {
    private ArrayList<GameObject> gameObjectList;

    public Game(int n) {
        gameObjectList = new ArrayList<>(n);
    }

    public void addGameObject(GameObject obj) {
        gameObjectList.add(obj);
    }

    public void drawAll() {
        for (GameObject obj : gameObjectList) {
            obj.draw();
        }
    }
}

abstract class GameObject{
    protected final String name;
    protected int x;
    protected int y;

    public GameObject(int x, int y, String n) {
        this.name = n;
        this.x = x;
        this.y = y;
    }

    public GameObject() {
        this.name = "";
        this.x = 0;
        this.y = 0;
    }

    public abstract void draw();
}

class Player extends GameObject {
    private int health;

    public Player(int x, int y, String n) {
        super(x, y, n);
        this.health = 10;
    }

    public Player(int x, int y) {
        this(x, y, "22K-4080");
    }

    @Override
    public void draw() {
        System.out.println("draw of Player class");
    }

    public boolean equals(Player obj) {
        return this.health == obj.health;
    }
}

class Enemy extends GameObject {
    private int damage;

    public Enemy(int x, int y, String n) {
        super(x, y, n);
        this.damage = 0;
    }

    public Enemy(int x, int y) {
        this(x, y, "22K-4080");
    }

    @Override
    public void draw() {
        System.out.println("draw of Enemy class");
    }
}

class PowerUp extends GameObject {
    private int effect;

    public PowerUp(int x, int y, String n) {
        super(x, y, n);
        this.effect = 0;
    }

    public PowerUp(int x, int y) {
        this(x, y, "22K-4080");
    }

    @Override
    public void draw() {
        System.out.println("draw of PowerUp class");
    }
}

public class Q4 {
    public static void main(String[] args) {
        Game game = new Game(4);

        Player plyr1 = new Player(0, 0);
        Enemy plyr2 = new Enemy(1, 5);
        PowerUp obj = new PowerUp(2, 2);
        Player plyr3 = new Player(3, 3);

        game.addGameObject(plyr1);
        game.addGameObject(plyr2);
        game.addGameObject(obj);
        game.addGameObject(plyr3);

        game.drawAll();

        if (plyr1.equals(plyr3)) {
            System.out.println("Successfully overloaded");
        }
    }
}
