#include <iostream>

using namespace std;

int main(){
		string designation[8]={"CEO","CTO","CFO","VP","MGR","EMP","EMP"};
		cout<<"Enter Designation"<<endl;
		
		for (i=0;i<8;i++){
			cout<<"Designation "<<i+1<": ";
			cin>>designation;
		}
}
