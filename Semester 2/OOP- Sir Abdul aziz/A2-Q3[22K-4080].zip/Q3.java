class Product {
    protected String name;
    protected int price;

    public Product(String name, int price) {
        this.name = name;
        this.price = price;
    }

    public Product() {}

    public int get_discounted_price() {
        return price;
    }

    public void print_details() {
        System.out.println("product name: " + name + " price: " + price);
    }

    public Product operatorAnd(Product prod1) {
        Product prod2 = new Product();
        prod2.name = prod1.name + " & " + this.name;
        prod2.price = (prod1.price + this.price) / 2;
        return prod2;
    }
}

class Book extends Product {
    private String author;

    public Book(String name, String author) {
        super(name, 500);
        this.author = author;
    }

    public void print_details() {
        System.out.println("product name: " + name + " price: " + price + " author: " + author);
    }
}

class Electronics extends Product {
    private String brand;

    public Electronics(String name, String brand) {
        super(name, 15500);
        this.brand = brand;
    }
}

class Clothing extends Product {
    private String size;

    public Clothing(String name, String size) {
        super(name, 3500);
        this.size = size;
    }

    public int get_discounted_price() {
        return (int) (price * 0.9); // 10% discount
    }
}

abstract class Customer {
    protected String name;
    protected int balance;

    public Customer(String name, int balance) {
        this.name = name;
        this.balance = balance;
    }

    public abstract void buy_product(Book book);

    public abstract void buy_product(Electronics electronics);

    public abstract void buy_product(Clothing clothing);
}

class RegularCustomer extends Customer {
    public RegularCustomer(String name, int balance) {
        super(name, balance);
    }

    public void buy_product(Book book) {
        if (book.get_discounted_price() < balance) {
            System.out.println("book bought");
            balance -= book.get_discounted_price();
        } else {
            System.out.println("book cannot be bought");
        }
    }

    public void buy_product(Electronics electronics) {
        if (electronics.get_discounted_price() < balance) {
            System.out.println("electronics bought");
            balance -= electronics.get_discounted_price();
        } else {
            System.out.println("electronics cannot be bought");
        }
    }

    public void buy_product(Clothing clothing) {
        if (clothing.get_discounted_price() < balance) {
            System.out.println("clothing bought");
            balance -= clothing.get_discounted_price();
        } else {
            System.out.println("clothing cannot be bought");
        }
    }
}
class VipCustomer extends Customer {
    public VipCustomer(String n, int b) {
        super(n, b);
    }

    @Override
    public void buy_product(Book book) {
        if ((book.get_discounted_price() * 0.8) < balance) {
            System.out.println("book bought");
            balance -= book.get_discounted_price();
        } else {
            System.out.println("book cannot be bought");
        }
    }

    @Override
    public void buy_product(Electronics electronics) {
        if ((electronics.get_discounted_price() * 0.8) < balance) {
            System.out.println("electronics bought");
            balance -= electronics.get_discounted_price();
        } else {
            System.out.println("electronics cannot be bought");
        }
    }

    @Override
    public void buy_product(Clothing cloths) {
        if ((cloths.get_discounted_price() * 0.8) < balance) {
            System.out.println("cloths bought");
            balance -= cloths.get_discounted_price();
        } else {
            System.out.println("cloths cannot be bought");
        }
    }
}

public class Q3 {
    public static void main(String[] args) {
        Book book = new Book("the subtle art of giving", "charles dicken");
        Electronics smartphone = new Electronics("Smartphone", "Samsung");
        Clothing clothing = new Clothing("pants", "small");

        RegularCustomer customer1 = new RegularCustomer("abc", 1000);
        customer1.buy_product(book);
        customer1.buy_product(smartphone);

        VipCustomer customer2 = new VipCustomer("Richie Rich", 20000);
        customer2.buy_product(smartphone);
        customer2.buy_product(smartphone);

        // ___________________________________________________________________

        Product p1 = new Product("headphones", 60);
        Product p2 = new Product("mouse", 20);
        Product p3 = p1.operatorAnd(p2);
        p3.print_details();
    }
}

