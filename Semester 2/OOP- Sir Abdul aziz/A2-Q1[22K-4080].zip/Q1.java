import java.util.*;
import java.util.Scanner;
class Juice {
    private float price;
    private String ingredients;
    private String taste;
    private static int count = 0;

    public Juice(float price, String ingredients, String taste) {
        this.price = price;
        this.ingredients = ingredients;
        this.taste = taste;
        count++;
    }

    public void setPrice(float price) {
        this.price = price;
    }

    public void setIngredients(String ingredients) {
        this.ingredients = ingredients;
    }

    public void setTaste(String taste) {
        this.taste = taste;
    }

    public float getPrice() {
        return price;
    }

    public String getIngredients() {
        return ingredients;
    }

    public String getTaste() {
        return taste;
    }

    public static int getCount() {
        return count;
    }

    public void display() {
        System.out.println("Juice Price: " + price);
        System.out.println("Juice Ingredients: " + ingredients);
        System.out.println("Juice Taste: " + taste);
    }
}

class FruitJuice extends Juice {
    private String season;
    private static int count = 0;

    public FruitJuice(float price, String ingredients, String taste, String season) {
        super(price, ingredients, taste);
        this.season = season;
        count++;
    }

    public void setSeason(String season) {
        this.season = season;
    }

    public String getSeason() {
        return season;
    }

    public static int getCount() {
        return count;
    }

    public void display() {
        super.display();
        System.out.println("Season: " + season);
    }
}

class VegetableJuice extends Juice {
    private String origin;
    private static int count = 0;

    public VegetableJuice(float price, String ingredients, String taste, String origin) {
        super(price, ingredients, taste);
        this.origin = origin;
        count++;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }

    public String getOrigin() {
        return origin;
    }

    public static int getCount() {
        return count;
    }

    public void display() {
        super.display();
        System.out.println("Origin: " + origin);
    }
}

class MixedJuice extends Juice {
    private static int count = 0;

    public MixedJuice(float price, String ingredients, String taste) {
        super(price, ingredients, taste);
        count++;
    }

    public static int getCount() {
        return count;
    }

    public void display() {
        super.display();
    }
}

class CitrusJuice extends FruitJuice {
    private static int count = 0;

    public CitrusJuice(float price, String ingredients, String taste, String season) {
        super(price, ingredients, taste, season);
        count++;
    }

    public static int getCount() {
        return count;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes citrus fruit juice");
    }
}

class BerryJuice extends FruitJuice {
    private static int count = 0;

    public BerryJuice(float price, String ingredients, String taste, String season) {
        super(price, ingredients, taste, season);
        count++;
    }

    public static int getCount() {
        return count;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes berry fruit juice");
    }
}

class TropicalJuice extends FruitJuice {
    private static int ctr3 = 0;

    public TropicalJuice(float p, String i, String t, String s) {
        super(p, i, t, s);
        ctr3++;
    }

    public static int getCount3() {
        return ctr3;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes tropical fruit juice");
    }
}

class LeafyGreenJuice extends VegetableJuice {
    private static int ctr3 = 0;

    public LeafyGreenJuice(float p, String i, String t, String o) {
        super(p, i, t, o);
        ctr3++;
    }

    public static int getCount3() {
        return ctr3;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes leafy green juice");
    }
}

class RootVegetableJuice extends VegetableJuice {
    private static int ctr3 = 0;

    public RootVegetableJuice(float p, String i, String t, String o) {
        super(p, i, t, o);
        ctr3++;
    }

    public static int getCount3() {
        return ctr3;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes root veegtable juice");
    }
}

class MixedVegetableJuice extends VegetableJuice {
    private static int ctr3 = 0;

    public MixedVegetableJuice(float p, String i, String t, String o) {
        super(p, i, t, o);
        ctr3++;
    }

    public static int getCount3() {
        return ctr3;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes mixed vegetable juice");
    }
}

class FruitAndVeggieJuice extends MixedJuice {
    private static int ctr3 = 0;

    public FruitAndVeggieJuice(float p, String i, String t) {
        super(p, i, t);
        ctr3++;
    }

    public static int getCount3() {
        return ctr3;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes fruit and vegetable juice");
    }
}

class SmoothieJuice extends MixedJuice {
    private static int ctr3 = 0;

    public SmoothieJuice(float p, String i, String t) {
        super(p, i, t);
        ctr3++;
    }

    public static int getCount3() {
        return ctr3;
    }

    public void display() {
        super.display();
        System.out.println("22k-4080 Arham Khan also likes smoothie juice");
    }
}

class Sale {
    private int ID;
    private String custName;
    private float bill;
    private int numOfFruitJuice;
    private int numOfVeggieJuice;
    private int numOfMixedJuice;
    private static int id = 1;

    public Sale() {
        bill = 0;
        numOfFruitJuice = 0;
        numOfMixedJuice = 0;
        numOfVeggieJuice = 0;
    }

    public Sale(String n) {
        custName = n;
        ID = id;
        id++;
        bill = 0;
        numOfFruitJuice = 0;
        numOfMixedJuice = 0;
        numOfVeggieJuice = 0;
    }

    public void inc_num_fruit() {
        numOfFruitJuice++;
    }

    public void inc_num_veggie() {
        numOfVeggieJuice++;
    }

    public void inc_num_mixed() {
        numOfMixedJuice++;
    }

    public void calc_bill(int p) {
        bill = bill + p;
    }

    public int get_num_fruit() {
        return numOfFruitJuice;
    }

    public int get_num_veggie() {
        return numOfVeggieJuice;
    }

    public int get_num_mixed() {
        return numOfMixedJuice;
    }

    public float get_bill() {
        return bill;
    }

    public void display() {
        System.out.println("Customer Name:" + custName);
        System.out.println("Sales ID:" + ID);
        System.out.println("Number Of Fruit Juices:" + numOfFruitJuice);
        System.out.println("Number Of Vegetable Juices:" + numOfVeggieJuice);
        System.out.println("Number Of Mixed Juices:" + numOfMixedJuice);
        System.out.println("Bill:" + bill);
    }

    public static Sale operator(Sale a, Sale b) {
        Sale temp = new Sale();
        if (a.custName.equals(b.custName)) {
            temp.custName = a.custName;
            temp.bill = a.bill + b.bill;
            temp.numOfFruitJuice = a.numOfFruitJuice + b.numOfFruitJuice;
            temp.numOfMixedJuice = a.numOfMixedJuice + b.numOfMixedJuice;
            temp.numOfVeggieJuice = a.numOfVeggieJuice + b.numOfVeggieJuice;
            temp.ID = a.ID + b.ID;
            return temp;
        } else {
            System.out.println("INVALID! Customer name is different");
            return null;
        }
    }
}

public class Q1 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        String name;
        FruitJuice[] ptr1 = new FruitJuice[10];
        VegetableJuice[] ptr2 = new VegetableJuice[10];
        MixedJuice[] ptr3 = new MixedJuice[10];
        System.out.println("Arham Khan");
        System.out.println("22K-4080\n");
        System.out.println("\tWelcome to The Juice Shop");
        System.out.print("Enter your name: ");
        name = scanner.nextLine();
        Sale obj1 = new Sale(name);
        Sale obj2 = new Sale(name);
        int opt1, opt2, i = 0, j = 0, k = 0;
        System.out.println("\nWe have following categories of juices available:");
        do {
            System.out.println("0-Check out");
            System.out.println("1-Fruit Juice");
            System.out.println("2-Vegetable Juice");
            System.out.println("3-Mixed Juice");
            System.out.print("Enter option number of type of juice to proceed: ");
            opt1 = scanner.nextInt();
            if (opt1 == 1 && i != 10) {
                System.out.println("\t0-Main Menu");
                System.out.println("\t1-Citrus Juice       399");
                System.out.println("\t2-Berry Juice        599");
                System.out.println("\t3-Tropical Juice     450");
                do {
                    System.out.print("\tEnter option number to add juice for purchase: ");
                    opt2 = scanner.nextInt();
                    if (opt2 == 1) {
                        ptr1[i] = new CitrusJuice(399, "lemon,grapefruit and orange", "sweet and tangy flavour", "Winter");
                        i++;
                        obj1.calc_bill(399);
                        obj1.inc_num_fruit();
                    }
                    if (opt2 == 2) {
                        ptr1[i] = new BerryJuice(599, "strawberry,blueberry and raspberry", "sweet flavour", "Winter");
                        i++;
                        obj1.calc_bill(599);
                        obj1.inc_num_fruit();
                    }
                    if (opt2 == 3) {
                        ptr1[i] = new TropicalJuice(450, "lychee and papaya", "sweet and sour flavour", "summer");
                        i++;
                        obj2.calc_bill(450);
                        obj2.inc_num_fruit();
                    }
                } while (opt2 != 0 && i != 10);
                if (i == 10) {
                    System.out.println("Sorry! Limit reached for Fruit Juice");
                }
            }
            if (i == 10) {
                System.out.println("Sorry! Limit reached for Fruit Juice");
            }
            if ((opt1 == 2) && (j != 10)) {
                System.out.println("\t0-Main Menu");
                System.out.println("\t1-Leafy Green Juice          499");
                System.out.println("\t2-Root Vegetable Juice       299");
                System.out.println("\t3-Mixed Vegetable Juice      750");
                do {
                    System.out.print("\tEnter option number to add juice for purchase: ");
                    opt2 = scanner.nextInt();
                    if (opt2 == 1) {
                        ptr2[j] = new LeafyGreenJuice(499, "kale,spinach and celery", "bitter and earthy taste", "Persia and England");
                        j++;
                        obj2.calc_bill(499);
                    }
                    if (opt1 == 2 && j != 10) {
                        System.out.println("\t0-Main Menu");
                        System.out.println("\t1-Leafy Green Juice 499");
                        System.out.println("\t2-Root Vegetable Juice 299");
                        System.out.println("\t3-Mixed Vegetable Juice 750");
                        do {
                            System.out.println("\tEnter option number to add juice for purchase:");
                            opt2 = scanner.nextInt();
                            if (opt2 == 1) {
                                ptr2[j] = new LeafyGreenJuice(499, "kale,spinach and celery", "bitter and earthy taste", "Persia and England");
                                j++;
                                obj2.calc_bill(499);
                                obj2.inc_num_veggie();
                            }
                            if (opt2 == 2) {
                                ptr2[j] = new RootVegetableJuice(299, "carrots,ginger and turnips", "bitter flavour", "Iran");
                                j++;
                                obj2.calc_bill(299);
                                obj2.inc_num_veggie();
                            }
                            if (opt2 == 3) {
                                ptr2[j] = new MixedVegetableJuice(750, "carrots,spinach,ginger and kale", "bitter and sour flavour", "Iran and England");
                                j++;
                                obj1.calc_bill(750);
                                obj1.inc_num_veggie();
                            }
                        } while (opt2 != 0 && j != 10);
                        if (j == 10) {
                            System.out.println("Sorry!Limit reached for Vegetable Juice");
                        }
                    }
                    if (j == 10) {
                        System.out.println("Sorry!Limit reached for Vegetable Juice");
                    }
                } while (opt2 != 0);
            }
                if (opt1 == 3 && k != 10) {
                    System.out.println("\t0-Main Menu");
                    System.out.println("\t1-Fruit and Veggie Juice 799");
                    System.out.println("\t2-Smoothie Juice 750");
                    do {
                        System.out.println("\tEnter option number to add juice for purchase:");
                        opt2 = scanner.nextInt();
                        if (opt2 == 1) {
                            ptr3[k] = new FruitAndVeggieJuice(799, "strawberry,lychee,ginger and carrots", "sweet and sour taste");
                            k++;
                            obj2.calc_bill(799);
                            obj2.inc_num_mixed();
                        }
                        if (opt2 == 2) {
                            ptr3[k] = new SmoothieJuice(750, "spinach,pineapple and mango", "bitter and sour flavour");
                            k++;
                            obj1.calc_bill(750);
                            obj1.inc_num_mixed();
                        }
                    } while (opt2 != 0 && k != 10);
                    if (k == 10) {
                        System.out.println("Sorry!Limit reached for Mixed Juice");
                    }
                }
                if (k == 10) {
                    System.out.println("Sorry!Limit reached for Mixed Juice");
                    }


            }while (opt1 != 0) ;

                    System.out.println("\nBill 01:\n");
                    obj1.display();
                    System.out.println("\nBill 02:\n");
                    obj2.display();
                    System.out.println("\n----Final Bill----");
                    Sale obj3 = Sale.operator(obj1, obj2);
                    obj3.display();


        }
    }
