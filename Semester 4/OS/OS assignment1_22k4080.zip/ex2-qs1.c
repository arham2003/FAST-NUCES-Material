#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main(int argc, char *argv[]){
	printf("We are in another program\n");
	printf("Hello OS - 22k4080\n");
	
	return 0;
}
